import React from 'react';
import TodoApp from './views/TodoApp';
import './styles/styles.css';

const App = () => (
  <div>
    <TodoApp />
  </div>
);

export default App;
